Thanks for using the Plugin.

Please go to the settings page in the dashboard for this plugin.
It is always a good idea to disable the plugin and then update to new version, and then re-enable, and check settings.

original Plugin by @peregrine,Redistributed by VrijVlinder with  Peregrine's permission.
 


